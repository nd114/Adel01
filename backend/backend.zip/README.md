# Adel
