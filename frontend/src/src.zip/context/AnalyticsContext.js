import { createContext, useState, useEffect } from 'react';
import api from '../api'; //import axios from 'axios';

const AnalyticsContext = createContext();

export const AnalyticsProvider = ({ children }) => {
  const [userAnalytics, setUserAnalytics] = useState({});
  const [serviceAnalytics, setServiceAnalytics] = useState({});
  const [bookingAnalytics, setBookingAnalytics] = useState({});

  useEffect(() => {
    const fetchAnalytics = async () => {
      const token = localStorage.getItem('token');
      const [userRes, serviceRes, bookingRes] = await Promise.all([
        api.get(/*(axios.get(*/'/api/analytics/users', { headers: { 'x-auth-token': token } }),
        api.get(/*(axios.get(*/'/api/analytics/services', { headers: { 'x-auth-token': token } }),
        api.get(/*(axios.get(*/'/api/analytics/bookings', { headers: { 'x-auth-token': token } })
      ]);

      setUserAnalytics(userRes.data);
      setServiceAnalytics(serviceRes.data);
      setBookingAnalytics(bookingRes.data);
    };

    fetchAnalytics();
  }, []);

  return (
    <AnalyticsContext.Provider value={{ userAnalytics, serviceAnalytics, bookingAnalytics }}>
      {children}
    </AnalyticsContext.Provider>
  );
};

export default AnalyticsContext;
