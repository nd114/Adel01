import { createContext, useState, useEffect } from 'react';
import api from '../api'; //import axios from 'axios';

const RatingContext = createContext();

export const RatingProvider = ({ children }) => {
  const [ratings, setRatings] = useState([]);
  const [filteredRatings, setFilteredRatings] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCriteria, setFilterCriteria] = useState({});

  useEffect(() => {
    const fetchRatings = async () => {
      const res = await api.get(/*(axios.get(*/'/api/ratings');
      setRatings(res.data);
      setFilteredRatings(res.data);
    };

    fetchRatings();
  }, []);

  useEffect(() => {
    filterAndSearchRatings();
  }, [searchTerm, filterCriteria, ratings]);

  const filterAndSearchRatings = () => {
    let result = ratings;

    if (searchTerm) {
      result = result.filter(rating =>
        rating.comment.toLowerCase().includes(searchTerm.toLowerCase()) ||
        rating.user.username.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterCriteria.rating) {
      result = result.filter(rating => rating.rating === filterCriteria.rating);
    }

    setFilteredRatings(result);
  };

  const createRating = async (ratingData) => {
    const token = localStorage.getItem('token');
    const res = await api.post(/*axios.post*/'/api/ratings', ratingData, { headers: { 'x-auth-token': token } });
    setRatings((prevRatings) => [...prevRatings, res.data]);
  };

  const updateRating = async (id, ratingData) => {
    const token = localStorage.getItem('token');
    const res = await api.put(/*axios.put*/`/api/ratings/${id}`, ratingData, { headers: { 'x-auth-token': token } });
    setRatings((prevRatings) => prevRatings.map((rating) => (rating._id === id ? res.data : rating)));
  };

  const deleteRating = async (id) => {
    const token = localStorage.getItem('token');
    await api.delete(/*axios.delete*/`/api/ratings/${id}`, { headers: { 'x-auth-token': token } });
    setRatings((prevRatings) => prevRatings.filter((rating) => rating._id !== id));
  };

  return (
    <RatingContext.Provider value={{
      ratings,
      filteredRatings,
      createRating,
      updateRating,
      deleteRating,
      searchTerm,
      setSearchTerm,
      filterCriteria,
      setFilterCriteria
    }}>
      {children}
    </RatingContext.Provider>
  );
};

export default RatingContext;
