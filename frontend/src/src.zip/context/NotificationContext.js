import { createContext, useState, useEffect } from 'react';
import api from '../api'; //import axios from 'axios';

const NotificationContext = createContext();

export const NotificationProvider = ({ children }) => {
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    const fetchNotifications = async () => {
      const token = localStorage.getItem('token');
      const res = await api.get(/*(axios.get(*/'/api/notifications', {
        headers: { 'x-auth-token': token },
      });
      setNotifications(res.data);
    };

    fetchNotifications();
  }, []);

  const createNotification = async (message) => {
    const token = localStorage.getItem('token');
    const res = await api.post(/*axios.post*/'/api/notifications', { message }, {
      headers: { 'x-auth-token': token },
    });
    setNotifications((prevNotifications) => [res.data, ...prevNotifications]);
  };

  const markAsRead = async (id) => {
    const token = localStorage.getItem('token');
    await api.put(/*axios.put*/`/api/notifications/${id}`, { read: true }, {
      headers: { 'x-auth-token': token },
    });
    setNotifications((prevNotifications) => 
      prevNotifications.map((notification) => 
        notification._id === id ? { ...notification, read: true } : notification
      )
    );
  };

  return (
    <NotificationContext.Provider value={{ notifications, createNotification, markAsRead }}>
      {children}
    </NotificationContext.Provider>
  );
};

export default NotificationContext;