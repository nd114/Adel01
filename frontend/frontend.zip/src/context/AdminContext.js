import { createContext, useState, useEffect } from 'react';
import api from '../api'; //import axios from 'axios';

const AdminContext = createContext();

export const AdminProvider = ({ children }) => {
  const [users, setUsers] = useState([]);
  const [services, setServices] = useState([]);

  useEffect(() => {
    const fetchUsersAndServices = async () => {
      const token = localStorage.getItem('token');
      const [usersRes, servicesRes] = await Promise.all([
        api.get(/*(axios.get(*/'/api/admin/users', { headers: { 'x-auth-token': token } }),
        api.get(/*(axios.get(*/'/api/admin/services', { headers: { 'x-auth-token': token } })
      ]);
      setUsers(usersRes.data);
      setServices(servicesRes.data);
    };

    fetchUsersAndServices();
  }, []);

  const deleteUser = async (id) => {
    const token = localStorage.getItem('token');
    await api.delete(/*axios.delete*/`/api/admin/users/${id}`, { headers: { 'x-auth-token': token } });
    setUsers(users.filter((user) => user._id !== id));
  };

  const deleteService = async (id) => {
    const token = localStorage.getItem('token');
    await api.delete(/*axios.delete*/`/api/admin/services/${id}`, { headers: { 'x-auth-token': token } });
    setServices(services.filter((service) => service._id !== id));
  };

  return (
    <AdminContext.Provider value={{ users, services, deleteUser, deleteService }}>
      {children}
    </AdminContext.Provider>
  );
};

export default AdminContext;
