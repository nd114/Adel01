import { createContext, useState, useEffect } from 'react';
import api from '../api'; //import axios from 'axios';

const BookingContext = createContext();

export const BookingProvider = ({ children }) => {
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    const fetchBookings = async () => {
      const res = await api.get(/*(axios.get(*/'/api/bookings');
      setBookings(res.data);
    };

    fetchBookings();
  }, []);

  const createBooking = async (bookingData) => {
    const token = localStorage.getItem('token');
    const res = await api.post(/*axios.post*/'/api/bookings', bookingData, { headers: { 'x-auth-token': token } });
    setBookings((prevBookings) => [...prevBookings, res.data]);
  };

  const updateBooking = async (id, bookingData) => {
    const token = localStorage.getItem('token');
    const res = await api.put(/*axios.put*/`/api/bookings/${id}`, bookingData, { headers: { 'x-auth-token': token } });
    setBookings((prevBookings) => prevBookings.map((booking) => (booking._id === id ? res.data : booking)));
  };

  const deleteBooking = async (id) => {
    const token = localStorage.getItem('token');
    await api.delete(/*axios.delete*/`/api/bookings/${id}`, { headers: { 'x-auth-token': token } });
    setBookings((prevBookings) => prevBookings.filter((booking) => booking._id !== id));
  };

  return (
    <BookingContext.Provider value={{ bookings, createBooking, updateBooking, deleteBooking }}>
      {children}
    </BookingContext.Provider>
  );
};

export default BookingContext;
