import { createContext, useState, useEffect } from 'react';
import api from '../api'; //import axios from 'axios';

const MessageContext = createContext();

export const MessageProvider = ({ children }) => {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const fetchMessages = async () => {
      const token = localStorage.getItem('token');
      const res = await api.get(/*(axios.get(*/'/api/messages', {
        headers: { 'x-auth-token': token },
      });
      setMessages(res.data);
    };

    fetchMessages();
  }, []);

  const sendMessage = async (messageData) => {
    const token = localStorage.getItem('token');
    const res = await api.post(/*axios.post*/'/api/messages', messageData, {
      headers: { 'x-auth-token': token },
    });
    setMessages((prevMessages) => [res.data, ...prevMessages]);
  };

  return (
    <MessageContext.Provider value={{ messages, sendMessage }}>
      {children}
    </MessageContext.Provider>
  );
};

export default MessageContext;
