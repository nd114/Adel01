//manage serviece state

import { createContext, useState, useEffect } from 'react';
import api from '../api'; //import axios from 'axios';

const ServiceContext = createContext();

export const ServiceProvider = ({ children }) => {
  const [services, setServices] = useState([]);

  useEffect(() => {
    const fetchServices = async () => {
      const res = await api.get(/*(axios.get(*/'/api/services');
      setServices(res.data);
    };

    fetchServices();
  }, []);

  const createService = async (serviceData) => {
    const token = localStorage.getItem('token');
    const res = await api.post(/*axios.post*/'/api/services', serviceData, { headers: { 'x-auth-token': token } });
    setServices((prevServices) => [...prevServices, res.data]);
  };

  const updateService = async (id, serviceData) => {
    const token = localStorage.getItem('token');
    const res = await api.put(/*axios.put*/`/api/services/${id}`, serviceData, { headers: { 'x-auth-token': token } });
    setServices((prevServices) => prevServices.map((service) => (service._id === id ? res.data : service)));
  };

  const deleteService = async (id) => {
    const token = localStorage.getItem('token');
    await api.delete(/*axios.delete*/`/api/services/${id}`, { headers: { 'x-auth-token': token } });
    setServices((prevServices) => prevServices.filter((service) => service._id !== id));
  };

  return (
    <ServiceContext.Provider value={{ services, createService, updateService, deleteService }}>
      {children}
    </ServiceContext.Provider>
  );
};

export default ServiceContext;
