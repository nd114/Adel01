# Adel
